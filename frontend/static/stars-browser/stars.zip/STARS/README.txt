This is stars 2.6jRC4
 